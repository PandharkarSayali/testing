import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilepicture',
  templateUrl: './profilepicture.component.html',
  styleUrls: ['./profilepicture.component.css']
})
export class ProfilepictureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
