const express = require('express');
var router =new express.Router();

var jsondata={
    
    "User1":{
       "UserName":"Ada Lovelace",
       "Email":"Ada@xyz.com",
       "FirstName":" Ada",
       "LastName":"Lovelace",
       "Role":"Admin", 
       "Actions":50,
       "id":2
    },

    "User2":{
       "UserName":"Grace Hopper",
       "Email":"Grace@xyz.com",
       "FirstName":" Grace",
       "LastName":"LoveHopperlace",
       "Role":"Developer", 
       "Actions":94,
       "id":1
    },

    "User3":{
       "UserName":"Margarel Hamilton",
       "Email":"AMargarelda@xyz.com",
       "FirstName":" Margarel",
       "LastName":"Hamilton",
       "Role":"QA", 
       "Actions":80,
       "id":4
    },

    "User4":{
       "UserName":"Joan Clarke",
       "Email":"Joan@xyz.com",
       "FirstName":" Joan",
       "LastName":"Clarke",
       "Role":"Manager", 
       "Actions": null,
       "id":3
    }
}

router.get('/',(req,res)=>{
        console.log("Error")
                    res.send(jsondata);
                
})

router.get('/:id',(req,res)=>{
    
        var id=req.params.id;
       // data.findById(id,(err, data)=>{
        data.find(({id:id}).value(),(err, data)=>{
            if(!err) {
                res.send(JSON.parse(data));
            } 
            else{
                    console.log(JSON.stringify(err,null,2));
                }
        })
    })

router.post('/', (req,res)=>
{
    //const filedata=require('jsonpath');
    const filedata=null;
    const file=req.body;
    filedata.push(file);
    fs.writeFile('jsonpath',json.stringify(filedata),err=>{
        if (err){
            console.log(err);
        }
        else{
            res.send(data);
        }
    })
    
})

router.delete('/:id',(req,res)=>
{
    var id=req.params.id;
        data.findByIdAndRemove(id,(err, data)=>{
            if(!err) {
                res.send(JSON.parse(data));
            } 
            else{
                    console.log(JSON.stringify(err,null,2));
                }
        })
})
module.exports=router;


