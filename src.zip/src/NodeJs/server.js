import('body-parser').BodyParser;

const express=require('express');
const bodyParser=require('body-parser');
const path=require('path');

var routes =require('./routes/routes');
var app=express();
const port=process.env.PORT||'8080';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({'extended':'false'}));
//angular dist folder here
//app.use(express.static(path.join(__dirname, 'dist/first-project-angular')));
//app.use('/users', express.static(path.join(__dirname, 'dist/first-project-angular')));
app.use('/users',routes);

var http = require('http');
var app1 = http.createServer(function(req,res){
    res.setHeader('Content-Type', 'application/json');
});  
app1.listen(port, ()=>console.log('Server started at port :8080'));
